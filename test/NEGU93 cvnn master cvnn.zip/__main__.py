from cvnn import cli
import sys
import logging
from pdb import set_trace

cli.cli()
